/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitorwidgetsolutionchatgpt;

/**
 *
 * @author kim2
 */
public class PriceCheckingVisitor implements ComponentVisitor{
    private double maxPrice;

    public PriceCheckingVisitor(double maxPrice) {
        this.maxPrice = maxPrice;
    }

    @Override
    public void visit(Widget widget) {
        double price = widget.getPrice();
        if (price > maxPrice) {
            System.out.println("Don't Buy! Widget price of " +
                    price + " exceeds maximum price (" + maxPrice + ").");
        } else {
            System.out.println("Buy! Widget price of " + price +
                    " is less than maximum price (" + maxPrice + ").");
        }
    }

    @Override
    public void visit(WidgetAssembly widgetAssembly) {
        double price = widgetAssembly.getPrice();
        if (price > maxPrice) {
            System.out.println("Don't Buy! WidgetAssembly price of " +
                    price + " exceeds maximum price (" + maxPrice + ").");
        } else {
            System.out.println("Buy! WidgetAssembly price of " + price +
                    " is less than maximum price (" + maxPrice + ").");
        }
    }    
}
