/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package visitorwidgetsolutionchatgpt;

/**
 *
 * @author kim2
 */
public interface ComponentVisitor {
    void visit(Widget widget);
    void visit(WidgetAssembly widgetAssembly);    
}
