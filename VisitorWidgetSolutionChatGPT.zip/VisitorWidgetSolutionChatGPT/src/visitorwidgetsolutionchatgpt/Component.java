/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitorwidgetsolutionchatgpt;

/**
 *
 * @author kim2
 */
public abstract class Component {
    protected String name;

    public Component(String name) {
        this.name = name;
    }

    // Existing code...

    public abstract void accept(ComponentVisitor visitor);
    
    public abstract double getPrice();
    public void setName(String name) { 
        this.name = 	name; 
    }    
    // Other methods...
}
