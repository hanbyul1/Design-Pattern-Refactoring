/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitorwidgetsolutionchatgpt;

/**
 *
 * @author kim2
 */
public class Widget extends Component{

    protected double price;

    public Widget(String name, double price) {
        super(name);
        this.price = price;
    }
    
    // Existing code...

    @Override
    public void accept(ComponentVisitor visitor) {
        visitor.visit(this);
    }

    public double getPrice() {
        return price;
    }    
}
