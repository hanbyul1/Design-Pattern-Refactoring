/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitorwidgetsolutionchatgpt;

import java.util.Enumeration;
import java.util.Vector;
/**
 *
 * @author kim2
 */
public class WidgetAssembly extends Component {
    
    private Vector<Component> components;

        public WidgetAssembly(String name) {
        super(name);
        components = new Vector<>();
    }

    public void addComponent(Component c) {
        components.addElement(c);
    }

    public void removeComponent(Component c) {
        components.removeElement(c);
    }

    // Existing code...

    @Override
    public void accept(ComponentVisitor visitor) {
        visitor.visit(this);
        for (Component component : components) {
            component.accept(visitor);
        }
    }

    public double getPrice() {
        double totalPrice = 0.0;
        Enumeration<Component> e = components.elements();
        while (e.hasMoreElements()) {
            totalPrice += e.nextElement().getPrice();
        }
        return totalPrice;
    }
// Existing code...    
}
