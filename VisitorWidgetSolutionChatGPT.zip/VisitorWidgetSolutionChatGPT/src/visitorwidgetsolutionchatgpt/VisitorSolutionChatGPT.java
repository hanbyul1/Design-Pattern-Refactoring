/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package visitorwidgetsolutionchatgpt;

/**
 *
 * @author kim2
 */
public class VisitorSolutionChatGPT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Widget w1 = new Widget("Widget1", 10.00);
        Widget w2 = new Widget("Widget2", 20.00);
        Widget w3 = new Widget("Widget3", 30.00);

        WidgetAssembly wa = new WidgetAssembly("Chassis");
        wa.addComponent(w1);
        wa.addComponent(w2);
        wa.addComponent(w3);

        ComponentVisitor visitor = new PriceCheckingVisitor(40.00);
        wa.accept(visitor);    
    }
    
}
