/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodesolutionchatgpt;

/**
 *
 * @author kim2
 */
public class AssignmentNode extends Node {

    private VariableRefNode left;
    private ExpressionNode right;

    public AssignmentNode(VariableRefNode left, ExpressionNode right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public void accept(NodeVisitor visitor) {
        visitor.visitAssignmentNode(this);
    }

    // Getters for left and right nodes
    public VariableRefNode getLeft() {
        return left;
    }

    public ExpressionNode getRight() {
        return right;
    }
}
