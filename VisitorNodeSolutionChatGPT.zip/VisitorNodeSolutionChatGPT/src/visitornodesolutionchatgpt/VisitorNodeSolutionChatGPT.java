/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package visitornodesolutionchatgpt;

/**
 *
 * @author kim2
 */

import java.util.Arrays;

public class VisitorNodeSolutionChatGPT {
    public static void main(String[] args) {
        // Create nodes
        VariableRefNode x = new VariableRefNode("x");
        VariableRefNode y = new VariableRefNode("y");
        //VariableRefNode z = new VariableRefNode("z");

        // Create an assignment and expression nodes
        AssignmentNode asgmt = new AssignmentNode(x, new ExpressionNode(Arrays.asList(y)));
        //ExpressionNode complexExpression = new ExpressionNode(Arrays.asList(assignment1, z));

        // Create the object structure and add nodes
        ObjectStructure structure = new ObjectStructure();
        structure.add(asgmt);

        // Create visitors
        NodeVisitor typeCheckVisitor = new TypeCheckVisitor();
        NodeVisitor generateCodeVisitor = new GenerateCodeVisitor();
        NodeVisitor prettyPrintVisitor = new PrettyPrintVisitor();

        // Apply visitors to all nodes in the structure
        for (Node node : structure.getNodes()) {
            node.accept(typeCheckVisitor);
            node.accept(generateCodeVisitor);
            node.accept(prettyPrintVisitor);
            System.out.println(); // New line for readability between nodes
        }
    }

    // TypeCheckVisitor, GenerateCodeVisitor, and PrettyPrintVisitor classes are assumed to be defined elsewhere
}
