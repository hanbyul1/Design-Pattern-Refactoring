/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodesolutionchatgpt;

/**
 *
 * @author kim2
 */
public class PrettyPrintVisitor implements NodeVisitor {
    @Override
    public void visitAssignmentNode(AssignmentNode node) {
        node.getLeft().accept(this);
        System.out.print(" = ");
        node.getRight().accept(this);
    }

    @Override
    public void visitExpressionNode(ExpressionNode node) {
        for (Node child : node.getChildren()) {
            child.accept(this);
        }
    }

    @Override
    public void visitVariableRefNode(VariableRefNode node) {
        System.out.print("Variable: " + node.getVariableName());
    }
}
