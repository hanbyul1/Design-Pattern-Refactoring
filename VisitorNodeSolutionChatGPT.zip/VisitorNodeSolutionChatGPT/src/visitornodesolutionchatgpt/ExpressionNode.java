/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodesolutionchatgpt;

/**
 *
 * @author kim2
 */
import java.util.List;

public class ExpressionNode extends Node {

    private List<Node> children;

    public ExpressionNode(List<Node> children) {
        this.children = children;
    }

    @Override
    public void accept(NodeVisitor visitor) {
        visitor.visitExpressionNode(this);
        // Optionally, you can also have the ExpressionNode handle traversing its children
        for (Node child : children) {
            child.accept(visitor);
        }
    }

    // Getter for children nodes
    public List<Node> getChildren() {
        return children;
    }
}

