/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodesolutionchatgpt;

/**
 *
 * @author kim2
 */
import java.util.Vector;

public class ObjectStructure {
    private Vector<Node> nodes = new Vector<>();

    public void add(Node node) {
        nodes.addElement(node);
    }

    public void remove(Node node) {
        nodes.removeElement(node);
    }

    public Vector<Node> getNodes() {
        return nodes;
    }

    // The methods typeCheckAll, generateCodeAll, and prettyPrintAll are removed
    // because these operations will now be handled by visitors.
}

