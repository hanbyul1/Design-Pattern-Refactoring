/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodesolutionchatgpt;

/**
 *
 * @author kim2
 */
public class VariableRefNode extends Node {

    private String variableName;

    public VariableRefNode(String variableName) {
        this.variableName = variableName;
    }

    @Override
    public void accept(NodeVisitor visitor) {
        visitor.visitVariableRefNode(this);
    }

    // Getter for variable name
    public String getVariableName() {
        return variableName;
    }
}
