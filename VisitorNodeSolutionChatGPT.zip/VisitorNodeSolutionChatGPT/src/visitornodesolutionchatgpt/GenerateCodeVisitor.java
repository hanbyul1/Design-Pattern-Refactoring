/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodesolutionchatgpt;

/**
 *
 * @author kim2
 */
public class GenerateCodeVisitor implements NodeVisitor {
    @Override
    public void visitAssignmentNode(AssignmentNode node) {
        node.getLeft().accept(this);
        node.getRight().accept(this);
        System.out.println("Generating code for assignment.");
    }

    @Override
    public void visitExpressionNode(ExpressionNode node) {
        for (Node child : node.getChildren()) {
            child.accept(this);
        }
        System.out.println("Generating code for expression.");
    }

    @Override
    public void visitVariableRefNode(VariableRefNode node) {
        System.out.println("Generating code for variable: " + node.getVariableName());
    }
}