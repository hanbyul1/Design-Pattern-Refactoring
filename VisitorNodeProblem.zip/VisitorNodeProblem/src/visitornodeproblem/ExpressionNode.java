/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodeproblem;

/**
 *
 * @author kim2
 */
import java.util.List;

public class ExpressionNode extends Node {

    private List<Node> children;

    public ExpressionNode(List<Node> children) {
        this.children = children;
    }

    @Override
    public void TypeCheck() {
        for (Node child : children) {
            child.TypeCheck();
        }
        System.out.println("Type checking for expression.");
    }

    @Override
    public void GenerateCode() {
        for (Node child : children) {
            child.GenerateCode();
        }
        System.out.println("Generating code for expression.");
    }

    @Override
    public void PrettyPrint() {
        for (Node child : children) {
            child.PrettyPrint();
        }
    }
}