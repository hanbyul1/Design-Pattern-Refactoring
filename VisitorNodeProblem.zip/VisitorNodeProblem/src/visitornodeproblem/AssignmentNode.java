/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodeproblem;

/**
 *
 * @author kim2
 */
public class AssignmentNode extends Node {

    private VariableRefNode left;
    private ExpressionNode right;

    public AssignmentNode(VariableRefNode left, ExpressionNode right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public void TypeCheck() {
        left.TypeCheck();
        right.TypeCheck();
        System.out.println("Type checking for assignment.");
    }

    @Override
    public void GenerateCode() {
        left.GenerateCode();
        right.GenerateCode();
        System.out.println("Generating code for assignment.");
    }

    @Override
    public void PrettyPrint() {
        left.PrettyPrint();
        System.out.print(" = ");
        right.PrettyPrint();
    }
}