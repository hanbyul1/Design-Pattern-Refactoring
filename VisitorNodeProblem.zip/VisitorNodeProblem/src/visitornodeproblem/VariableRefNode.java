/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodeproblem;

/**
 *
 * @author kim2
 */
public class VariableRefNode extends Node {

    private String variableName;

    public VariableRefNode(String variableName) {
        this.variableName = variableName;
    }

    @Override
    public void TypeCheck() {
        System.out.println("Type checking for variable: " + variableName);
    }

    @Override
    public void GenerateCode() {
        System.out.println("Generating code for variable: " + variableName);
    }

    @Override
    public void PrettyPrint() {
        System.out.println("Variable: " + variableName);
    }
}