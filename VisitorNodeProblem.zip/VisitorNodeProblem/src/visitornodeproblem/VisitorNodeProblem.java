/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package visitornodeproblem;

/**
 *
 * @author kim2
 */
import java.util.Arrays;

public class VisitorNodeProblem {
    public static void main(String[] args) {
        VariableRefNode x = new VariableRefNode("x");
        VariableRefNode y = new VariableRefNode("y");
        //VariableRefNode z = new VariableRefNode("z");

        AssignmentNode asgmt = new AssignmentNode(x, new ExpressionNode(Arrays.asList(y)));
        //ExpressionNode complexExpression = new ExpressionNode(Arrays.asList(assignment1, z));

        ObjectStructure structure = new ObjectStructure();
        structure.add(asgmt);

        // Perform operations on all nodes in the structure
        structure.typeCheckAll();
        structure.generateCodeAll();
        structure.prettyPrintAll();
    }
}
