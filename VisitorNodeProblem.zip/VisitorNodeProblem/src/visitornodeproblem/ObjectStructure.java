/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitornodeproblem;

/**
 *
 * @author kim2
 */
import java.util.Vector;

public class ObjectStructure {
    private Vector<Node> nodes = new Vector<>();

    public void add(Node node) {
        nodes.addElement(node);
    }

    public void remove(Node node) {
        nodes.removeElement(node);
    }

    public Vector<Node> getNodes() {
        return nodes;
    }

    // You can also include methods to perform operations on all nodes
    public void typeCheckAll() {
        for (Node node : nodes) {
            node.TypeCheck();
        }
    }

    public void generateCodeAll() {
        for (Node node : nodes) {
            node.GenerateCode();
        }
    }

    public void prettyPrintAll() {
        for (Node node : nodes) {
            node.PrettyPrint();
        }
    }
}
