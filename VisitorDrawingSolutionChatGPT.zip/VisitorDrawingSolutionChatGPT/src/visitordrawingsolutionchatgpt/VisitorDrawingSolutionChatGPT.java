/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package visitordrawingsolutionchatgpt;

/**
 *
 * @author kim2
 */
public class VisitorDrawingSolutionChatGPT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ObjectStructure objectStructure = new ObjectStructure();
        Picture picture1 = new Picture("picture1");
        Line line1 = new Line("line1");
        Line line2 = new Line("line2");
        Point point1 = new Point("point1");
        Point point2 = new Point("point2");
        Point point3 = new Point("point3");
        Point point4 = new Point("point4");

        line1.add(point1);
        line1.add(point2);
        line2.add(point3);
        line2.add(point4);
        picture1.add(line1);
        picture1.add(line2);
        objectStructure.add(picture1);

        DrawingVisitor visitor = new DrawingVisitor();
        objectStructure.accept(visitor);
    }    
}
