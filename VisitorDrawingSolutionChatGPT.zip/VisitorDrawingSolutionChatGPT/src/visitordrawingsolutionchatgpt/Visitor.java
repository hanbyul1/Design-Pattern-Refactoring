/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package visitordrawingsolutionchatgpt;

/**
 *
 * @author kim2
 */
public interface Visitor {
    void visit(Line line);
    void visit(Point point);
    void visit(Picture picture);
    void visit(Rectangle rectangle);
}
