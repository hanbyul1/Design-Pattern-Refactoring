/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitordrawingsolutionchatgpt;

/**
 *
 * @author kim2
 */
public class DrawingVisitor implements Visitor {
    public void visit(Line line) {
        System.out.println(line.getName() + " is created");
    }

    public void visit(Point point) {
        System.out.println(point.getName() + " is created");
    }

    public void visit(Picture picture) {
        System.out.println(picture.getName()  + " is created");
    }

    public void visit(Rectangle rectangle) {
        System.out.println(rectangle.getName() + " is created");
    }
}
