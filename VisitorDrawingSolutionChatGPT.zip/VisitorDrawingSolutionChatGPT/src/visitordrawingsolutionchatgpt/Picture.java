/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitordrawingsolutionchatgpt;

import java.util.Enumeration;
import java.util.Vector;

/**
 *
 * @author kim2
 */
public class Picture extends DrawObject {
    private Vector<DrawObject> objects = new Vector<>();

    public Picture(String name) {
        this.name = name;
    }

    public void add(DrawObject obj) {
        objects.addElement(obj);
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
        Enumeration<DrawObject> enumeration = objects.elements();
        while (enumeration.hasMoreElements()) {
            enumeration.nextElement().accept(visitor);
        }
    }
}