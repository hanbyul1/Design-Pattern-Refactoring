/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitordrawingsolutionchatgpt;

import java.util.Enumeration;
import java.util.Vector;

/**
 *
 * @author kim2
 */
public class Rectangle extends DrawObject {
    private Vector<Point> points = new Vector<>();

    public Rectangle(String name) {
        this.name = name;
    }

    public void add(Point point) {
        points.addElement(point);
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
        Enumeration<Point> enumeration = points.elements();
        while (enumeration.hasMoreElements()) {
            enumeration.nextElement().accept(visitor);
        }
    }
}
