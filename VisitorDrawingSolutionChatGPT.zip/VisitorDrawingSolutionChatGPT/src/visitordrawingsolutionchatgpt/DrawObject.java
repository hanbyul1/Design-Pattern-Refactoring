/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package visitordrawingsolutionchatgpt;

/**
 *
 * @author kim2
 */
import java.util.Enumeration;
import java.util.Vector;

public abstract class DrawObject {
    protected String name;

    public abstract void accept(Visitor visitor);

    public String getName() {
        return name;
    }
}